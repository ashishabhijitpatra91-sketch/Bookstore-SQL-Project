# Bookstore SQL Analysis Project

**Author:** Ashish Abhijit Patra  
**Database:** PostgreSQL  
**Project type:** Bookstore sales and inventory analysis

## Overview

A portfolio-ready PostgreSQL project that models a small bookstore and answers practical questions about books, customers, orders, revenue, and inventory. The project uses a fresh schema, original sample records, and reusable analysis queries.

## Features

- Relational schema with primary keys, foreign keys, and validation constraints
- Sample bookstore data for repeatable practice
- Sales, genre, author, customer, and inventory analysis
- Views for order-level sales reporting
- Common table expressions (CTEs), joins, aggregates, subqueries, and window functions

## Repository structure

```text
Bookstore-SQL-Analysis-Ashish-Abhijit-Patra/
├── README.md
├── LICENSE
├── .gitignore
├── sql/
│   ├── 01_schema_and_seed.sql
│   └── 02_analysis_queries.sql
└── data/
    └── README.md
```

## Requirements

- PostgreSQL 14 or newer (PostgreSQL 14+ recommended)
- `psql` command-line client or pgAdmin
- Git (only needed to publish to GitHub)

## Setup with psql

1. Create a database:

   ```sql
   CREATE DATABASE bookstore_analysis;
   ```

2. Connect to it:

   ```bash
   psql -U postgres -d bookstore_analysis
   ```

3. Run the schema and sample data script from the project root:

   ```bash
   psql -U postgres -d bookstore_analysis -f sql/01_schema_and_seed.sql
   ```

4. Run the analysis queries:

   ```bash
   psql -U postgres -d bookstore_analysis -f sql/02_analysis_queries.sql
   ```

If you use pgAdmin, open `sql/01_schema_and_seed.sql` in the Query Tool for the `bookstore_analysis` database and execute it. Then open and execute `sql/02_analysis_queries.sql`.

> The schema script drops and recreates the project's `bookstore` schema. Use it only in the dedicated project database, because it replaces any existing schema with that name.

## Data model

- `bookstore.books`: title, author, genre, publication year, price, and stock
- `bookstore.customers`: customer contact and location fields
- `bookstore.orders`: customer, book, order date, quantity, and unit price at the time of purchase

Each order row represents one book line item. `unit_price` is captured on the order so historical sales calculations do not change if the current book price changes.

## Analysis questions

1. What are all books and their current stock levels?
2. Which genres generate the most sales revenue?
3. Which books have sold the most units?
4. What is the revenue by month?
5. Which customers have spent the most?
6. Which authors have the highest unit sales?
7. Which books are below the low-stock threshold?
8. What is the average order-line value?
9. Which customers have placed at least two orders?
10. What is the cumulative monthly revenue trend?

## Important interpretation notes

- Revenue in this practice dataset is calculated as `quantity * unit_price`.
- This sample does not model refunds, taxes, shipping, discounts, or payment status.
- Inventory remaining is calculated as initial/current `stock` minus recorded units sold. For a production system, stock updates should be handled transactionally when orders are placed.
- The included records are fictional sample data for learning and demonstration.

## Publish to GitHub

Create a new empty repository on GitHub named `Bookstore-SQL-Analysis-Ashish-Abhijit-Patra`. From this project folder, run:

```bash
git init
git add .
git commit -m "Add PostgreSQL bookstore analysis project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/Bookstore-SQL-Analysis-Ashish-Abhijit-Patra.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. Do not put passwords, access tokens, or database credentials in the repository.

## Author

**Ashish Abhijit Patra**

This is an independently prepared learning project using fictional sample data, inspired by the general topic of bookstore SQL analysis.
