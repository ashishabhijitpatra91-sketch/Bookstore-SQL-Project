# Sample data

Sample records are embedded directly in `sql/01_schema_and_seed.sql` so the project can be run without downloading CSV files or editing local file paths. All customer records are fictional and use reserved `example.com` email addresses.
