-- Bookstore SQL Analysis Project
-- Author: Ashish Abhijit Patra
-- Run after sql/01_schema_and_seed.sql

-- 1. Browse the book catalogue.
SELECT book_id, title, author, genre, price, stock
FROM bookstore.books
ORDER BY title;

-- 2. Overall sales KPIs.
SELECT
    COUNT(*) AS order_lines,
    SUM(quantity) AS units_sold,
    ROUND(SUM(quantity * unit_price), 2) AS total_revenue,
    ROUND(AVG(quantity * unit_price), 2) AS avg_line_revenue
FROM bookstore.orders;

-- 3. Revenue and units sold by genre.
SELECT genre,
       SUM(quantity) AS units_sold,
       ROUND(SUM(quantity * unit_price), 2) AS revenue
FROM bookstore.order_sales
GROUP BY genre
ORDER BY revenue DESC;

-- 4. Best-selling books by units.
SELECT book_title, author,
       SUM(quantity) AS units_sold,
       ROUND(SUM(line_revenue), 2) AS revenue
FROM bookstore.order_sales
GROUP BY book_id, book_title, author
ORDER BY units_sold DESC, revenue DESC
LIMIT 10;

-- 5. Revenue by month (months without orders are not included).
SELECT DATE_TRUNC('month', order_date)::DATE AS sales_month,
       SUM(quantity) AS units_sold,
       ROUND(SUM(quantity * unit_price), 2) AS revenue
FROM bookstore.orders
GROUP BY DATE_TRUNC('month', order_date)
ORDER BY sales_month;

-- 6. Highest-spending customers.
SELECT customer_name,
       COUNT(DISTINCT order_id) AS order_lines,
       SUM(quantity) AS units_purchased,
       ROUND(SUM(line_revenue), 2) AS total_spend
FROM bookstore.order_sales
GROUP BY customer_id, customer_name
ORDER BY total_spend DESC
LIMIT 10;

-- 7. Sales by author.
SELECT author,
       SUM(quantity) AS units_sold,
       ROUND(SUM(line_revenue), 2) AS revenue
FROM bookstore.order_sales
GROUP BY author
ORDER BY units_sold DESC, revenue DESC;

-- 8. Low-stock book alert (threshold: fewer than 8 copies).
SELECT book_id, title, author, stock
FROM bookstore.books
WHERE stock < 8
ORDER BY stock ASC, title;

-- 9. Customers with at least two order lines.
SELECT c.customer_id, c.full_name, COUNT(o.order_id) AS order_lines
FROM bookstore.customers AS c
JOIN bookstore.orders AS o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.full_name
HAVING COUNT(o.order_id) >= 2
ORDER BY order_lines DESC, c.full_name;

-- 10. Average listed price by genre.
SELECT genre,
       ROUND(AVG(price), 2) AS average_price,
       MIN(price) AS lowest_price,
       MAX(price) AS highest_price
FROM bookstore.books
GROUP BY genre
ORDER BY average_price DESC;

-- 11. Estimated units remaining after recorded sales.
-- Assumes books.stock is starting stock and all order rows are fulfilled.
WITH sold AS (
    SELECT book_id, SUM(quantity) AS units_sold
    FROM bookstore.orders
    GROUP BY book_id
)
SELECT b.book_id, b.title, b.stock AS starting_stock,
       COALESCE(s.units_sold, 0) AS units_sold,
       b.stock - COALESCE(s.units_sold, 0) AS estimated_remaining
FROM bookstore.books AS b
LEFT JOIN sold AS s ON s.book_id = b.book_id
ORDER BY estimated_remaining ASC, b.title;

-- 12. Running cumulative revenue by month (window function).
WITH monthly AS (
    SELECT DATE_TRUNC('month', order_date)::DATE AS sales_month,
           SUM(quantity * unit_price) AS revenue
    FROM bookstore.orders
    GROUP BY DATE_TRUNC('month', order_date)
)
SELECT sales_month,
       ROUND(revenue, 2) AS monthly_revenue,
       ROUND(SUM(revenue) OVER (ORDER BY sales_month), 2) AS cumulative_revenue
FROM monthly
ORDER BY sales_month;

-- 13. Books priced above the average catalogue price (subquery).
SELECT title, author, price
FROM bookstore.books
WHERE price > (SELECT AVG(price) FROM bookstore.books)
ORDER BY price DESC;

-- 14. Rank books within each genre by revenue (CTE + window function).
WITH book_revenue AS (
    SELECT book_id, book_title, genre,
           SUM(line_revenue) AS revenue
    FROM bookstore.order_sales
    GROUP BY book_id, book_title, genre
)
SELECT genre, book_title,
       ROUND(revenue, 2) AS revenue,
       DENSE_RANK() OVER (PARTITION BY genre ORDER BY revenue DESC) AS genre_rank
FROM book_revenue
ORDER BY genre, genre_rank, book_title;

-- 15. Order-line detail for a date range.
-- Change the dates as required.
SELECT order_id, order_date, customer_name, book_title,
       quantity, unit_price, line_revenue
FROM bookstore.order_sales
WHERE order_date BETWEEN DATE '2025-01-01' AND DATE '2025-12-31'
ORDER BY order_date, order_id;
